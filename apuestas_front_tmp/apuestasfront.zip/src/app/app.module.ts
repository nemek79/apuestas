import { HttpLoaderService } from './fwk/services/http-loader.service';
import { AuthService } from './fwk/services/auth.service';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TestComponent } from './components/test/test.component';
import { HeaderComponent } from './fwk/components/navegacion/header/header.component';
import { DashboardComponent } from './components/movil/dashboard/dashboard.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpInterceptorService } from './fwk/services/http-interceptor.service';

@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    HeaderComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [
    // Framework INI
    AuthService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpInterceptorService,
      multi: true
    },
    HttpLoaderService
    // Framework FIN
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
