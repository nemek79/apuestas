export class Usuario {

  username!: string;
  password!: string;
  roles: string[] = [];
  email!: string;
  picture: any ;
  nombre!: string;
  apellidos!: string;
  passwordNew!: string;
  passwordRepeat!: string;

}
