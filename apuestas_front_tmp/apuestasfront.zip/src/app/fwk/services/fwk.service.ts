import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: 'root'
})
export class FwkService{

  constructor(
    private http: HttpClient
  ) {

  }

  // INI => FUNCIONES PARA EL CONTROL DEL LOCAL STORAGE & SESION STORAGE
  public setItem(key: string, value: string): void {

    localStorage.setItem(environment.app + '.' + key, value);

  }

  public getItem(key: string): string {

    let resultado = localStorage.getItem(environment.app + '.' + key);

    return  resultado !== null ? resultado : '';

  }

  public removeItem(key: string): void {

    localStorage.removeItem(environment.app + '.' + key);

  }

  public clear(): void {

    localStorage.clear();

  }

  public setItemSession(key: string, value: string): void {

    sessionStorage.setItem(environment.app + '.' + key, value);

  }

  public getItemSession(key: string): string {

    let resultado = sessionStorage.getItem(environment.app + '.' + key);

    return  resultado !== null ? resultado : '';

  }

  public removeItemSession(key: string): void {

    sessionStorage.removeItem(environment.app + '.' + key);

  }

  public clearSession(): void {

    sessionStorage.clear();

  }

  // FIN => FUNCIONES PARA EL CONTROL DEL LOCAL STORAGE & SESION STORAGE

}
