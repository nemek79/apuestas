export const environment = {
  production: true,
  client: 'APUESTAS',
  clientPass: 'huFNJmSWv1PygAbbFCVo',
  urlEndPointAuth: 'http://vir2al.es:8099',
  urlBack: 'http://localhost:7001/api',
  app: 'apu'
};
